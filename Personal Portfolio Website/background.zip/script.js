var typed = new Typed(".text", {
    strings: ["Full Stack Developer", "Front-End Developer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});